#ifndef _HFTA_SFUN_H_INCLUDED_
#define _HFTA_SFUN_H_INCLUDED_

#include "vstring.h"
#include "host_tuple.h"

////////////////////////////////////////////////////////////////
///		Dummy state and functions, for testing

void _sfun_state_destroy_Foo(char(*)[20] );
void _sfun_state_dirty_init_Foo(char(*)[20],char(*)[20], int);
void _sfun_state_final_init_Foo(char(*)[20], int);
void _sfun_state_clean_init_Foo(char(*)[20]);
unsigned int Bar(char(*)[20], int, unsigned int);

int packet_count(void *s, int curr_num_samples);
double gamma(void *s, int curr_num_samples);
int init_threshold(void *s, int curr_num_samples);
int do_clean_count(void *s, int curr_num_samples);
int delay(void *s, int curr_num_samples);
int newly_closed(void *s, int curr_num_samples);


////////////////////////////////////////////////////////////////////
///             Manku-Motwani Heavy Hitters
////////////////////////////////////////////////////////////////////
void _sfun_state_clean_init_manku_hh_state(void *s);
void _sfun_state_dirty_init_manku_hh_state(void *s_new, void *s_old, int curr_num_samples);
void _sfun_state_final_init_manku_hh_state(void *s, int curr_num_samples);
void _sfun_state_destroy_manku_hh_state(void *s){};

/////////////////////////////////////////////////////////////////////

#endif
