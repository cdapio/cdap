#ifndef SELECTION_OPERATOR_H
#define SELECTION_OPERATOR_H

#include "host_tuple.h"
#include "base_operator.h"
#include <list>
using namespace std;

template <class select_project_functor> class select_project_operator :
		public base_operator
{
private :
	select_project_functor func;
public:

	select_project_operator(int schema_handle, const char* name) : base_operator(name), func(schema_handle) { }

	virtual int accept_tuple(host_tuple& tup, list<host_tuple>& result) {
		host_tuple res;

		if (func.predicate(tup)) {
			res = func.create_output_tuple();
			res.channel = output_channel;
			result.push_back(res);
		} else {
			if (func.temp_status_received()) {
				if (!func.create_temp_status_tuple(res)) {
					res.channel = output_channel;
					result.push_back(res);
				}
			}
		}
		tup.free_tuple();
		return 0;
	}

	virtual int flush(list<host_tuple>& result) {
		return 0;
	}

	virtual int set_param_block(int sz, void * value) {
		func.set_param_block(sz, value);
		return 0;
	}

	virtual int get_temp_status(host_tuple& result) {
		result.channel = output_channel;
		return func.create_temp_status_tuple(result);
	}

	virtual int get_blocked_status () {
		return -1;		// selection operators are not blocked on any input
	}
};

#endif	// SELECTION_OPERATOR_H
