#ifndef __HFTA_RUNTIME_LIBRARY__
#define __HFTA_RUNTIME_LIBRARY__
#include "host_tuple.h"
#include "gsconfig.h"
#include "gstypes.h"

#define DNS_SAMPLE_HASH_SZ 50000000
#define DNS_HITLIST_HASH_SZ 50000000
#define DNS_HITLIST_ENTRY_SZ 500000

struct DNS_sample_hash_entry {
    gs_uint32_t lastTime;
    gs_uint32_t startTime;
    gs_uint8_t sampled;
};


struct DNS_sample_state {
    gs_int8_t * filename;
    gs_uint32_t filelastread;
    gs_uint8_t hitlist_hash[DNS_HITLIST_HASH_SZ];
    gs_int8_t * hitlist_entry[DNS_HITLIST_ENTRY_SZ];
    gs_uint32_t hitlist_entry_len[DNS_HITLIST_ENTRY_SZ];
    gs_uint64_t CnumberOfFlows;
    gs_uint64_t CnumberOfSampledFlows;
    struct DNS_sample_hash_entry Chash[DNS_SAMPLE_HASH_SZ];
    gs_uint64_t AnumberOfFlows;
    gs_uint64_t AnumberOfSampledFlows;
    struct DNS_sample_hash_entry Ahash[DNS_SAMPLE_HASH_SZ];
};


//		Internal functions
gs_retval_t Vstring_Constructor(vstring *, gs_sp_t);
gs_retval_t hfta_vstr_length(vstring *);
void hfta_vstr_assign_with_copy_in_tuple(vstring32 *, vstring *, gs_sp_t, int);
void hfta_vstr_assign_with_copy(vstring *, vstring *);
void hfta_vstr_destroy(vstring *);
void hfta_vstr_replace(vstring *, vstring *);

gs_uint32_t hfta_vstr_hashfunc(const vstring *);
gs_retval_t hfta_vstr_compare(const vstring *, const vstring *);

gs_retval_t hfta_ipv6_compare(const hfta_ipv6_str &i1, const hfta_ipv6_str &i2);
hfta_ipv6_str And_Ipv6(const hfta_ipv6_str &i1, const hfta_ipv6_str &i2);
hfta_ipv6_str Or_Ipv6(const hfta_ipv6_str &i1, const hfta_ipv6_str &i2);
gs_uint32_t hfta_ipv6_hashfunc(const hfta_ipv6_str *s) ;
hfta_ipv6_str hton_ipv6(hfta_ipv6_str s);
hfta_ipv6_str ntoh_ipv6(hfta_ipv6_str s);
gs_retval_t HFTA_Ipv6_Constructor(hfta_ipv6_str *s, gs_sp_t l) ;




//		External functions

inline static gs_retval_t str_truncate(vstring * result, vstring *str, gs_uint32_t length) {
	result->offset=str->offset;
	result->length=(str->length<length)?str->length:length;
	result->reserved=SHALLOW_COPY;
	return 0;
}

gs_retval_t str_exists_substr(vstring * s1, vstring * s2);
gs_retval_t str_compare(vstring * s1, vstring * s2);
gs_uint32_t byte_match_reverse_offset( gs_uint32_t offset, gs_uint32_t val,vstring *s2) ;

// HTTP header based Application matching 

gs_param_handle_t register_handle_for_http_app_match_slot_1(vstring* filename);
gs_retval_t deregister_handle_for_http_app_match_slot_1(gs_param_handle_t handle);
gs_uint32_t str_match_offset(gs_uint32_t offset,vstring *s1,vstring *s2);
gs_uint32_t byte_match_offset( gs_uint32_t offset, gs_uint32_t val,vstring *s2);

// PREPARSED HTTP header based Application matching
gs_param_handle_t register_handle_for_http_preparse_app_match_slot_5(vstring* filename);
gs_retval_t http_preparse_app_match(vstring * result, gs_uint32_t time, gs_uint32_t interval,  vstring * url, 
	vstring * useragent, vstring * mime, gs_param_handle_t handle);
gs_retval_t deregister_handle_for_http_preparse_app_match_slot_5(gs_param_handle_t handle);

// REGEX functions

gs_param_handle_t register_handle_for_str_file_regex_match_slot_1(vstring* filename);
gs_uint32_t str_file_regex_match(vstring * str, gs_param_handle_t handle, gs_uint32_t timeout, gs_uint32_t time);
gs_retval_t deregister_handle_for_str_file_regex_match_slot_1(gs_param_handle_t handle);

gs_retval_t str_regex_match(vstring* str, gs_param_handle_t pattern_handle);
gs_param_handle_t register_handle_for_str_regex_match_slot_1(vstring* pattern);
gs_retval_t deregister_handle_for_str_regex_match_slot_1(gs_param_handle_t handle);

gs_retval_t str_partial_regex_match(vstring* str, gs_param_handle_t pattern_handle);
gs_param_handle_t register_handle_for_str_partial_regex_match_slot_1(vstring* pattern);
gs_retval_t deregister_handle_for_str_partial_regex_match_slot_1(gs_param_handle_t handle);

gs_param_handle_t register_handle_for_str_extract_regex_slot_1(vstring* pattern);
gs_retval_t str_extract_regex( vstring * result, vstring * str, gs_param_handle_t handle);
gs_retval_t deregister_handle_for_str_extract_regex_slot_1(gs_param_handle_t handle);


gs_param_handle_t register_handle_for_str_extract_regex_null_slot_1(vstring* pattern);
gs_retval_t str_extract_regex_null( vstring * result, vstring * str, gs_param_handle_t handle);
gs_retval_t deregister_handle_for_str_extract_regex_null_slot_1(gs_param_handle_t handle);


#define SAMPLEHITLISTRELOAD 60
#define DNSSAMPLELINESZ 1024

static inline gs_uint32_t DNS_sample_hitlist_qname_hash(vstring * DnsQStr)
{
    gs_uint64_t sh=1;;
    gs_uint32_t x;
    
    for(x=0;x<DnsQStr->length;x++) {
        gs_uint64_t t;
        t=(gs_uint64_t) (((gs_uint8_t *) DnsQStr->offset)[x]);
        sh=sh*t;
    }
    sh=sh%DNS_HITLIST_HASH_SZ;
    return (gs_uint32_t) sh;
    
}

static inline gs_uint32_t DNS_sample_reload_file(struct DNS_sample_state * d) {
    gs_int32_t res;
	FILE * f;
	gs_int8_t line[DNSSAMPLELINESZ];
	struct vstring s;
	gs_uint32_t x;
    
	memset(d->hitlist_hash,0,DNS_HITLIST_HASH_SZ);
	for(x=0;x<DNS_HITLIST_ENTRY_SZ;x++) {
		if (d->hitlist_entry[x]!=0) free(d->hitlist_entry[x]);
		d->hitlist_entry[x]=0;
	}
	x=0;
	if ((f=fopen(d->filename,"r"))==0) return 0;
	while ((fgets(&line[0],DNSSAMPLELINESZ-1,f)) != 0) {
		gs_uint32_t h;
		if ((strlen(line)>0) && (line[strlen(line)-1]=='\n')) line[strlen(line)-1]=0;
		s.length=strlen(line);
		s.offset=(gs_p_t)line;
		if (x<DNS_HITLIST_ENTRY_SZ) {
			d->hitlist_entry[x]=strdup(line);
			d->hitlist_entry_len[x]=strlen(d->hitlist_entry[x]);
		}
		x++;
		h=DNS_sample_hitlist_qname_hash(&s);
		d->hitlist_hash[h]=d->hitlist_hash[h]|(1<<(s.length%8));
	}
	fclose(f);
    return 1;
}

static inline gs_uint32_t DNS_sample_hitlist_hit(struct DNS_sample_state * d, vstring * DnsQStr) {
	gs_uint32_t x;
	if ((d->hitlist_hash[DNS_sample_hitlist_qname_hash(DnsQStr)]&(1<<(DnsQStr->length%8)))==0) return 0;
	for(x=0;x<DNS_HITLIST_ENTRY_SZ;x++) {
		if (d->hitlist_entry[x]==0) return 0;
		if (DnsQStr->length != d->hitlist_entry_len[x] ) continue;
		if (strncmp(d->hitlist_entry[x],((gs_int8_t *) DnsQStr->offset),DnsQStr->length)==0) return 1;
	}
	return 0;
}


static inline gs_uint32_t DNS_client_hash(gs_uint32_t clientIP, gs_uint32_t clientPort, gs_uint32_t DnsId) {
    
	gs_uint64_t d1,d2,d3;
    
	d1=(gs_uint64_t)clientIP;
	d2=(gs_uint64_t)clientPort;
	d3=(gs_uint64_t)DnsId;
	d1=d1*d2*d3;
	d1=d1%DNS_SAMPLE_HASH_SZ;
	//fprintf(stderr,"%u %u %u %u\n",clientIP,clientPort,DnsId,  (unsigned int) d1);
	return (unsigned int) d1;
}

static inline gs_uint32_t DNS_auth_hash(gs_uint32_t serverIP, gs_uint32_t serverPort, vstring * DnsQStr) {
	gs_uint64_t sh=1;;
	gs_uint64_t d1;
	gs_uint64_t d2;
	gs_uint32_t x;
    
	d1=(gs_uint64_t) serverIP;
	for(x=0;x<DnsQStr->length;x++) {
		gs_uint64_t t;
		t=(gs_uint64_t) (((gs_uint8_t *) DnsQStr->offset)[x]);
		sh=sh*t;
	}
	d1=d1*sh;
    d1=d1%DNS_SAMPLE_HASH_SZ;
    return (gs_uint32_t) d1;
}

static inline gs_uint32_t DNS_clientv6_hash(struct hfta_ipv6_str clientIP, gs_uint32_t clientPort, gs_uint32_t DnsId) {
    
    gs_uint64_t d1,d2,d3;
    
    d1=(gs_uint64_t)clientIP.v[0]^clientIP.v[1]^clientIP.v[2]^clientIP.v[3];
    d2=(gs_uint64_t)clientPort;
    d3=(gs_uint64_t)DnsId;
	//fprintf(stderr,"V6 %x %x %x\n",d1,d2,d3);
    d1=d1*d2*d3;
    d1=d1%DNS_SAMPLE_HASH_SZ;
    //fprintf(stderr,"%u %u %u %u\n",clientIP,clientPort,DnsId,  (unsigned int) d1);
    return (gs_uint32_t) d1;
}

static inline gs_uint32_t DNS_authv6_hash(struct hfta_ipv6_str serverIP, gs_uint32_t serverPort, vstring * DnsQStr) {
    gs_uint64_t sh=1;;
    gs_uint64_t d1;
    gs_uint64_t d2;
    gs_uint32_t x;
    
    d1=(gs_uint64_t) serverIP.v[0]^serverIP.v[1]^serverIP.v[2]^serverIP.v[3];
    for(x=0;x<DnsQStr->length;x++) {
        gs_uint64_t t;
        t=(gs_uint64_t) (((gs_uint8_t *) DnsQStr->offset)[x]);
        sh=sh*t;
    }
    d1=d1*sh;
    d1=d1%DNS_SAMPLE_HASH_SZ;
    return (gs_uint32_t) d1;
}


static inline gs_param_handle_t register_handle_for_DNS_sample_slot_0(vstring * hitlist)
{
	struct DNS_sample_state * d;
	if ((d=(struct DNS_sample_state *) malloc(sizeof(struct DNS_sample_state)))==0) return 0;
	memset(d,0,sizeof(struct DNS_sample_state));
	d->filename=strdup((const char *)hitlist->offset);
	if (d->filename==0) { free(d); return 0; }
	return (gs_param_handle_t) d;
}

static inline void deregister_handle_for_DNS_sample_slot_0(gs_param_handle_t handle)
{
    struct DNS_sample_state * d;
    if (handle==0) return;
    d=(struct DNS_sample_state *) handle;
	free(d->filename);
	free(d);
}




// Function for LPM

gs_param_handle_t register_handle_for_getlpmid_slot_1(struct vstring * s1);
gs_retval_t getlpmid(gs_uint32_t ip, gs_param_handle_t handle );
void deregister_handle_for_getlpmid_slot_1(gs_param_handle_t handle);

gs_param_handle_t register_handle_for_getfirstlpmid_slot_2(struct vstring * s1);
void deregister_handle_for_getfirstlpmid_slot_2(gs_param_handle_t handle);

// v6 LPM function

gs_param_handle_t register_handle_for_getv6lpmid_slot_1(struct vstring * s1);

gs_retval_t getv6lpmid(hfta_ipv6_str ip,gs_param_handle_t handle);

void deregister_handle_for_getv6lpmid_slot_1(gs_param_handle_t handle);


// Functions for smart sampling

gs_param_handle_t register_handle_for_nssample_slot_1(gs_uint32_t s1);
void deregister_handle_for_nssample_slot_1(gs_param_handle_t handle);

// simple if statement
#define IF(c,t,f) (((c)!=0)?(t):(f))

// type conversion
#define INT(c) ((int)(c))
#define UINT(c) ((gs_uint32_t)(c))
#define FLOAT(c) ((gs_float_t)(c))
#define ULLONG(c) ((gs_uint64_t)(c))
#define TIMESTAMPTOMSEC(c) ((gs_uint32_t) (((c)&0xffffffff)/4294967))

// string conversions

gs_uint32_t strtoi(gs_uint32_t * r, struct vstring *data);
gs_uint32_t strtoip(gs_uint32_t * r, struct vstring *data);

//	constant string conversions
gs_param_handle_t register_handle_for_strtoi_c_slot_0(vstring* istr) ;
gs_retval_t deregister_handle_for_strtoi_c_slot_0(gs_param_handle_t h) ;
#define strtoi_c(h) ((gs_uint32_t)(h))

gs_param_handle_t register_handle_for_strtoip_c_slot_0(vstring* istr) ;
gs_retval_t deregister_handle_for_strtoip_c_slot_0(gs_param_handle_t h) ;
#define strtoip_c(h) ((gs_uint32_t)(h))

inline static gs_uint32_t STRID(vstring *str) {
   gs_uint32_t res=0;
   gs_uint8_t c;
   if (str->length>0) c=(((gs_uint8_t *) str->offset)[0]); else c=0;
   res=(res|(gs_uint32_t)c)<<8;
   if (str->length>1) c=(((gs_uint8_t *) str->offset)[1]); else c=0;
   res=(res|(gs_uint32_t)c)<<8;
   if (str->length>2) c=(((gs_uint8_t *) str->offset)[2]); else c=0;
   res=(res|(gs_uint32_t)c)<<8;
   if (str->length>3) c=(((gs_uint8_t *) str->offset)[3]); else c=0;
   return (res|(gs_uint32_t)c);
}

inline gs_uint32_t str_match_offset( gs_uint32_t offset, struct vstring * s1, struct vstring * s2) {
	register gs_uint8_t *st1 = (gs_uint8_t *) s1->offset;
	register gs_uint8_t *st2 = (gs_uint8_t *) (s2->offset+offset);
	register gs_int32_t x;
	register gs_int32_t len2 = s2->length-offset;
	register gs_int32_t len1 = s1->length;
	if (len2<len1) return 0;
	for(x=0; x<len1; x++) {
		if (st1[x]!=st2[x]) return 0;
	}
	return 1;
}
 
inline gs_retval_t extract_responsecode(gs_uint32_t * r, struct vstring * s) {
	gs_uint32_t x=0;
	gs_uint8_t * c;
	*r=0;
	c=(gs_uint8_t *) s->offset;
	if (s->length <= (x+4)) return 1;
	if (c[x]!='H') return 1;
    if (c[x+1]!='T') return 1;
	if (c[x+2]!='T') return 1;
	if (c[x+3]!='P') return 1;
	x=x+4;
	while ((c[x] != 32))  { // find space
		x++;
		if (s->length <= x) return 1;
	}
	while ((c[x] > 57) || (c[x]<48))  { // find first number
		x++;
		if (s->length <= x) return 1;
	}
	if (s->length <= (x+2) ) return 1;
	if  ((c[x+1] > 57) || (c[x+1] <48)) return 1;
	if  ((c[x+2] > 57) || (c[x+2] <48)) return 1;
	*r=((((gs_uint32_t)c[x])-48)*100+((((gs_uint32_t)c[x+1])-48)*10)+((gs_uint32_t)c[x+2])-48);
	//fprintf(stderr,"xx %u %u %u %u \n",*r,(unsigned int)c[x],(unsigned int)c[x+1],(unsigned int)c[x+2]);
	return 0;
}


#endif 
