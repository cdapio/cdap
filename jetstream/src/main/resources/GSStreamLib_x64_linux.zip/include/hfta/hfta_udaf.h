#ifndef _HFTA_UDAF_H_INCLUDED_
#define _HFTA_UDAF_H_INCLUDED_

#include "vstring.h"
#include "host_tuple.h"
#include "gsconfig.h"
#include "gstypes.h"

// -------------------------------------------------------------------
//		sum over 3 intervals : test rUDAF
void sum3_HFTA_AGGR_INIT_(gs_sp_t buf) ;
void sum3_HFTA_AGGR_UPDATE_(gs_sp_t buf, gs_uint32_t s) ;
void sum3_HFTA_AGGR_OUTPUT_(gs_uint32_t *result, gs_sp_t buf) ;
void sum3_HFTA_AGGR_DESTROY_(gs_sp_t buf) ;
void sum3_HFTA_AGGR_REINIT_( gs_sp_t buf) ;


// -------------------------------------------------------------------
//		running sum over arbitrary intervals.
void moving_sum_udaf_HFTA_AGGR_INIT_(gs_sp_t buf) ;
void moving_sum_udaf_HFTA_AGGR_UPDATE_(gs_sp_t buf, gs_uint32_t s, gs_uint32_t N) ;
void moving_sum_udaf_HFTA_AGGR_OUTPUT_(gs_uint64_t *result, gs_sp_t buf) ;
void moving_sum_udaf_HFTA_AGGR_DESTROY_(gs_sp_t buf) ;
void moving_sum_udaf_HFTA_AGGR_REINIT_( gs_sp_t buf) ;

#define super_moving_sum_udaf_HFTA_AGGR_INIT_ moving_sum_udaf_HFTA_AGGR_INIT_
void super_moving_sum_udaf_HFTA_AGGR_UPDATE_(gs_sp_t buf, gs_uint64_t s) ;
#define super_moving_sum_udaf_HFTA_AGGR_OUTPUT_ moving_sum_udaf_HFTA_AGGR_OUTPUT_
#define super_moving_sum_udaf_HFTA_AGGR_DESTROY_ moving_sum_udaf_HFTA_AGGR_DESTROY_
#define super_moving_sum_udaf_HFTA_AGGR_REINIT_ moving_sum_udaf_HFTA_AGGR_REINIT_

gs_uint32_t moving_sum_extract(gs_uint64_t result);
gs_float_t moving_sum_extract_exp(gs_uint64_t result, gs_float_t alpha);

//--------------------------------------------------------------------
//              early regex matching
void early_regex_match_udaf_HFTA_AGGR_INIT_(gs_sp_t buf);
void early_regex_match_udaf_HFTA_AGGR_UPDATE_(gs_sp_t buf, vstring *regex, vstring *str, gs_uint32_t len, 
												gs_uint32_t syn, gs_uint32_t seq_num);
void early_regex_match_udaf_HFTA_AGGR_OUTPUT_(gs_uint64_t *r, gs_sp_t buf);
void early_regex_match_udaf_HFTA_AGGR_DESTROY_(gs_sp_t buf);
void early_regex_match_udaf_HFTA_AGGR_REINIT_( gs_sp_t buf);
gs_uint32_t early_regex_match_extract(gs_uint32_t result);
gs_uint32_t early_regex_match_extract_packet_count(gs_uint32_t result);
gs_float_t early_regex_match_extract_ave_list(gs_uint32_t result);
gs_uint32_t early_regex_match_extract_max_list(gs_uint32_t result);
gs_uint32_t early_regex_match_extract_until_match(gs_uint32_t result);
gs_uint32_t early_regex_match_extract_overlap(gs_uint32_t result);
gs_uint32_t early_regex_match_extract_duplicate(gs_uint32_t result);
gs_uint32_t early_regex_match_extract_max_end_states(gs_uint32_t result);
gs_uint32_t early_regex_match_extract_out_of_order(gs_uint32_t result);
gs_uint32_t early_regex_match_extract_merge_lists(gs_uint32_t result);
gs_uint32_t early_regex_match_extract_copy_list(gs_uint32_t result);

//--------------------------------------------------------------------
//              early regex matching - parallel version
void early_regex_match_udaf_eq_HFTA_AGGR_INIT_(gs_sp_t buf);
void early_regex_match_udaf_eq_HFTA_AGGR_UPDATE_(gs_sp_t buf, vstring *regex, vstring *str, gs_uint32_t len, 
												 gs_uint32_t syn, gs_uint32_t seq_num, gs_int32_t iter_num);
void early_regex_match_udaf_eq_HFTA_AGGR_OUTPUT_(gs_uint32_t *r, gs_sp_t buf);
void early_regex_match_udaf_eq_HFTA_AGGR_DESTROY_(gs_sp_t buf);
void early_regex_match_udaf_eq_HFTA_AGGR_REINIT_( gs_sp_t buf);
gs_uint32_t early_regex_match_extract_eq(gs_uint32_t result);
gs_uint32_t early_regex_match_extract_packet_count_eq(gs_uint32_t result);
gs_float_t early_regex_match_extract_ave_list_eq(gs_uint32_t result);
gs_uint32_t early_regex_match_extract_max_list_eq(gs_uint32_t result);
gs_uint32_t early_regex_match_extract_until_match_eq(gs_uint32_t result);
gs_uint32_t early_regex_match_extract_overlap_eq(gs_uint32_t result);
gs_uint32_t early_regex_match_extract_duplicate_eq(gs_uint32_t result);
gs_uint32_t early_regex_match_extract_max_end_states_eq(gs_uint32_t result);
gs_uint32_t early_regex_match_extract_out_of_order_eq(gs_uint32_t result);
gs_uint32_t early_regex_match_extract_merge_lists_eq(gs_uint32_t result);
gs_uint32_t early_regex_match_extract_copy_list_eq(gs_uint32_t result);

/////////////////////////////////////////////////////////////////////////
/////   Calculate the average of all positive float numbers

void POSAVG_HFTA_AGGR_INIT_(gs_sp_t buf);
void POSAVG_HFTA_AGGR_UPDATE_(gs_sp_t buf, gs_float_t v);
void POSAVG_HFTA_AGGR_OUTPUT_(gs_float_t * v, gs_sp_t buf);
void POSAVG_HFTA_AGGR_DESTROY_(gs_sp_t buf);


///////////////////////////////////////////////////////////////////
/////			avg_udaf (simple example)

//		hfta avg_udaf
void avg_udaf_HFTA_AGGR_INIT_(gs_sp_t b);
void avg_udaf_HFTA_AGGR_UPDATE_(gs_sp_t b, gs_uint32_t v);
void avg_udaf_HFTA_AGGR_OUTPUT_(vstring *r,gs_sp_t b);
void avg_udaf_HFTA_AGGR_DESTROY_(gs_sp_t b);

//		avg_udaf superaggregate
void avg_udaf_hfta_HFTA_AGGR_INIT_(gs_sp_t b);
void avg_udaf_hfta_HFTA_AGGR_UPDATE_(gs_sp_t b, vstring *v);
void avg_udaf_hfta_HFTA_AGGR_OUTPUT_(vstring *r,gs_sp_t b);
void avg_udaf_hfta_HFTA_AGGR_DESTROY_(gs_sp_t b);

//		Extraction function
gs_float_t extr_avg_fcn(vstring *v);

#define approx_hh_Buckets 256 // number of buckets...

typedef gs_uint16_t approx_hh_counters[2][3][approx_hh_Buckets];


////////////////////////////////////////////////////////////////
///		Flip's sample-based quantiles

/****************************************************************/
/* HFTA functions						*/
/****************************************************************/
gs_uint32_t extr_med_hfta3_fcn(vstring *);
gs_uint32_t extr_quant_hfta3_space(vstring *);

/****************************************************************/
/* HFTA-only functions						*/
/****************************************************************/
void quant_udaf_hfta0_HFTA_AGGR_INIT_(gs_sp_t);
void quant_udaf_hfta0_HFTA_AGGR_UPDATE_(gs_sp_t, gs_uint32_t);
void quant_udaf_hfta0_HFTA_AGGR_OUTPUT_(vstring *, gs_sp_t);
void quant_udaf_hfta0_HFTA_AGGR_DESTROY_(gs_sp_t);

////////////////////////////////////////////////////////////////
//              hfta bquant_cursor_udaf
void bquant_cursor_udaf_HFTA_AGGR_INIT_(gs_sp_t);
void bquant_cursor_udaf_HFTA_AGGR_UPDATE_(gs_sp_t, gs_uint32_t);
void bquant_cursor_udaf_HFTA_AGGR_OUTPUT_(vstring *, gs_sp_t);
void bquant_cursor_udaf_HFTA_AGGR_DESTROY_(gs_sp_t);

////////////////////////////////////////////////////////////////
// TCP sequence number stats
void tcp_seq_count_HFTA_AGGR_INIT_(gs_sp_t scratch);
void tcp_seq_count_HFTA_AGGR_UPDATE_(gs_sp_t scratch, gs_uint32_t sequence_number, 
									 gs_uint32_t data_length, gs_uint32_t flags);
void tcp_seq_count_HFTA_AGGR_OUTPUT_(gs_uint32_t * res,gs_sp_t scratch);
#define tcp_seq_count_HFTA_AGGR_DESTROY_(scratch)

////////////////////////////////////////////////////////////////
//             tos stats estimation

void tos_stats_udaf_HFTA_AGGR_INIT_(gs_sp_t scratch);
void tos_stats_udaf_HFTA_AGGR_UPDATE_(gs_sp_t scratch , gs_uint32_t tos);
void tos_stats_udaf_HFTA_AGGR_OUTPUT_(gs_uint64_t * res, gs_sp_t scratch);
#define tos_stats_udaf_HFTA_AGGR_DESTROY_(scratch) 

/****************************************************************/
/* HFTA functions  for simple_loss                              */
/****************************************************************/

void simple_loss_estimate_HFTA_AGGR_INIT_(gs_sp_t scratch);
void simple_loss_estimate_HFTA_AGGR_UPDATE_(gs_sp_t scratch,  gs_uint32_t prefixlen, gs_uint32_t seqnum);
void simple_loss_estimate_HFTA_AGGR_OUTPUT_(gs_uint32_t * res, gs_sp_t scratch);
#define simple_loss_estimate_HFTA_AGGR_DESTROY_(scratch)

#endif
