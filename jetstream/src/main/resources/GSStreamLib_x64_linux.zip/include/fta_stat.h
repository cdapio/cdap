
#ifndef FTA_STAT_H
#define FTA_STAT_H

/* statiss are collected by FTAs and regularly sent to cluster manager (currently every 1 sec)
 * Statistics refers to time interval since the last time statistics was reported */
typedef struct fta_stat {
   FTAID ftaid;
   gs_uint32_t in_tuple_cnt;		/* # of tuples received */
   gs_uint32_t out_tuple_cnt;		/* # of tuples produced */
   gs_uint32_t out_tuple_sz;		/* bytes in produced tuples */
   gs_uint32_t accepted_tuple_cnt;	/* # of tuples that passed initial unpacking and selection predicate */
   gs_uint64_t cycle_cnt;			/* # of cpu cycles spent in accept_tuple */
   gs_uint32_t collision_cnt;		/* # of collisions in an aggregation hash table */
   gs_uint32_t eviction_cnt;		/* # of collisions in an aggregation hash table */
   gs_float_t sampling_rate;			/* sampling rate used by fta */

  /* ...will add more fields in the future... */
} fta_stat;

#endif	/* FTA_STAT_H */
