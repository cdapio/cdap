#ifndef SYSTAT_H
#define SYSTAT_H

struct systemstat {
   gs_int32_t process_priority_level;
   gs_int32_t resource_priority_level;
  /* ... */
};

#endif
