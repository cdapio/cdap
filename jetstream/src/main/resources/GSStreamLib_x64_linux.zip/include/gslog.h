/*
 * gslog.h: syslog wrappers for Gigascope
 */
#ifndef GSLOG_H
#define GSLOG_H


#include "unistd.h"
#include "sys/syslog.h"
#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "time.h"
#include "gsconfig.h"
#include "gstypes.h"

#define gslog syslog

#ifndef LOG_EMERG
#define LOG_EMERG 7
#endif

// some state used for reporting

extern gs_uint64_t intupledrop;
extern gs_uint64_t outtupledrop;
extern gs_uint64_t intuple;
extern gs_uint64_t outtuple;
extern gs_uint64_t inbytes;
extern gs_uint64_t outbytes;
extern gs_uint64_t cycles;


static inline void gsopenlog(gs_sp_t p) {
	gs_int8_t c[HOST_NAME_MAX+1];
	gs_int8_t t[HOST_NAME_MAX+1+1000];
	gs_sp_t t2;
	if (gethostname(&c[0],HOST_NAME_MAX+1)!=0) {
		fprintf(stderr,"GSCPV1::ERROR:could not get hostname\n");
		exit(1);
	}
	c[HOST_NAME_MAX]=0;
	sprintf(t,"GSCPv2:%s:%s:",c,p);
	t2=strdup(t);
	openlog(t2,LOG_NOWAIT|LOG_PID|LOG_CONS,LOG_LOCAL5);
	gslog(LOG_INFO,"Started Logging");
	intupledrop=0;
	outtupledrop=0;
	intuple=0;
	outtuple=0;
	inbytes=0;
	outbytes=0;
	cycles=0;
}

static inline void gsstats() {
	gs_uint32_t t;
	//t=time(0);
	//gslog(LOG_NOTICE,"STATS|%u|%llu|%llu|%llu|%llu|%llu|%llu|%llu",t,intuple,inbytes,intupledrop,outtuple,outbytes,outtupledrop,cycles);
}
#endif
