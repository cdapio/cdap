#ifndef _TYPE_INDICATORS_DEFINED__
#define _TYPE_INDICATORS_DEFINED__

//      WARNING!
//      This file replicated in gscpv2/src/ftacmp
//      These files must be synched!


#define UINT_TYPE 0
#define INT_TYPE 1
#define ULLONG_TYPE 2
#define LLONG_TYPE 3
#define USHORT_TYPE 4
#define FLOAT_TYPE 5
#define BOOL_TYPE 6
#define VSTR_TYPE 7
#define TIMEVAL_TYPE 8
#define IP_TYPE 9
#define FSTRING_TYPE 10
#define IPV6_TYPE 11
#define UNDEFINED_TYPE 12



#endif

