#ifndef __RDTSC_H__
#define __RDTSC_H__

#include "gsconfig.h"
#include "gstypes.h"

#if defined(__i386__) || defined(__x86_64__)

static __inline__ gs_uint64_t rdtsc(void)
{
  gs_uint64_t x=0;
  gs_uint32_t low;
  gs_uint32_t high;
  __asm__ __volatile__("rdtsc" : "=a" (low), "=d" (high));
  x=((gs_uint64_t)high)<<32;
  x=x|((gs_uint64_t)low);
//     __asm__ volatile (".byte 0x0f, 0x31" : "=A" (x));
  return x;
}
#endif

#endif	// __RDTSC_H__

