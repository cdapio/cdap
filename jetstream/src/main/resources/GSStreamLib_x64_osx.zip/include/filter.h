/*
 * filter.h: hash table function which match the interface
 */
#ifndef FILTER_H
#define FILTER_H

/* FILTER FUNCTIONS */
/* ===============  */

/* The following functions are used to manage filter sets for flow
   and connection filters
*/

struct filter {
    gs_uint32_t size;
    gs_uint8_t data[1];
};

struct filter * ftafilter_create(gs_int32_t size); 
void ftafilter_delete(struct filter * filter); 
void ftafilter_add_flow ( struct filter * filter, gs_uint32_t ip, gs_uint32_t port);
void fyafilter_add_connection ( struct filter * filter, gs_uint32_t ip1, 
			     gs_uint32_t port1, gs_uint32_t ip2, gs_uint32_t port2);
void ftafilter_rm_flow ( struct filter * filter, gs_uint32_t ip, gs_uint32_t port);
void ftafilter_rm_connection ( struct filter * filter, gs_uint32_t ip1, 
			    gs_uint32_t port1, gs_uint32_t ip2, gs_uint32_t port2);
struct vstring * ftafilter_to_vstring(struct filter * f );
void ftafilter_vstring_free(struct vstring * res);


#endif
