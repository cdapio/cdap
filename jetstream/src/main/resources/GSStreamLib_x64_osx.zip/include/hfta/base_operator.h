
#ifndef BASE_OPERATOR_H
#define BASE_OPERATOR_H

#include "host_tuple.h"
#include <list>
using namespace std;

class base_operator
{
protected:
	unsigned int output_channel;
	const char* op_name;
public:
//			Tuple is presented to the operator.  Output tuples
//			returned in result
	virtual int accept_tuple(host_tuple& tup, list<host_tuple>& result) = 0;
//			Flush output from the system
	virtual int flush(list<host_tuple>& result) = 0;
//			Accept new query parameters
	virtual int set_param_block(int sz, void * value) = 0;
	virtual int get_temp_status(host_tuple& result) = 0;
	virtual int get_blocked_status () = 0;

	base_operator(const char* name) {
		output_channel = 0;
		op_name = name;
	}

	void set_output_channel(unsigned int channel) {
		output_channel = channel;
	}

//			Operator's memory footprint in bytes (estimate for the main structures - hash tables, etc )
	virtual unsigned int get_mem_footprint() { return 0;	}

	virtual const char* get_name() { return op_name; }
};

#endif	// BASE_OPERATOR_H
