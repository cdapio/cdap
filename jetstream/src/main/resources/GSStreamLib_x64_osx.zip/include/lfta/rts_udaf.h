#ifndef _RTS_UDAF_H_INCLUDED_
#define _RTS_UDAF_H_INCLUDED_

#include "gsconfig.h"
#include "gstypes.h"
#include "rts_external.h"


//			avg_udaf
void avg_udaf_lfta_LFTA_AGGR_INIT_(gs_sp_t);
void avg_udaf_lfta_LFTA_AGGR_UPDATE_(gs_sp_t,gs_uint32_t);
gs_retval_t avg_udaf_lfta_LFTA_AGBGR_FLUSHME_(gs_sp_t);
void avg_udaf_lfta_LFTA_AGGR_OUTPUT_(struct string *,gs_sp_t);
void avg_udaf_lfta_LFTA_AGGR_DESTROY_(gs_sp_t);

//		moving sum
void moving_sum_lfta_LFTA_AGGR_INIT_(gs_sp_t b);
void moving_sum_lfta_LFTA_AGGR_UPDATE_(gs_sp_t b, gs_uint32_t v, gs_uint32_t N);
gs_retval_t moving_sum_lfta_LFTA_AGGR_FLUSHME_(gs_sp_t b);
void moving_sum_lfta_LFTA_AGGR_OUTPUT_(gs_uint64_t *r, gs_sp_t b);
gs_retval_t moving_sum_lfta_LFTA_AGGR_DESTROY_(gs_sp_t b);

#define approx_hh_udaf_lfta_hashsize 128 // needs to be 2^i
#define approx_hh_udaf_lfta_hashmod 127 // need to be 2^i - 1
#define approx_hh_udaf_lfta_maxchain 9 // pick a small int that you like
#define approx_hh_udaf_lfta_hasha 1653695771 // pair of randomly chosen
#define approx_hh_udaf_lfta_hashb 1006449030 // 31 bit integers to hash with

typedef struct approx_hh_udaf_lfta_struct_t{
  gs_uint32_t id; 
  gs_uint32_t cnt;
} approx_hh_udaf_lfta_struct_t; // 8 bytes

typedef struct approx_hh_udaf_lfta_t{
  gs_uint8_t flag; // 1 byte
  approx_hh_udaf_lfta_struct_t hashtbl[approx_hh_udaf_lfta_hashsize];
} approx_hh_udaf_lfta_t; // should be approx 1k in size


//////////////////////////////////////////////////////////////////
///		Flip-s sample-based quantiles

/****************************************************************/
/* LFTA functions  for fm sketch								*/
/****************************************************************/

#define FMR_UDAF_LFTA_SIZE ((128 - sizeof(gs_uint32_t)) / sizeof(gs_uint32_t))


#endif
