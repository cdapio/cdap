
#include <stdlib.h>
#include <string.h>

/*
 * macro adaptor
 */
#define mod(a,b) ((a) % (b))

