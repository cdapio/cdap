#ifndef RTS_STRING_H
#define RTS_STRING_H
#include "gsconfig.h"
#include "gstypes.h"

//	struct string32 matches vstring32, its the packed record format.
//	struct string is the in-memory format.

struct string32{
	gs_int32_t length;
	gs_int32_t offset;
	gs_int32_t reserved;
};


/* struct string has to match definition in host.h however, the data
   types differ */

struct string {
    gs_int32_t length;
    gs_sp_t data;
    struct FTA * owner;
};

#include "fta.h"
#include "rts.h"

/* For regex match, UDP packets */

gs_uint32_t get_int(struct string *s, gs_uint32_t n);
gs_bool_t get_bool(struct string *s, gs_uint32_t n);

struct string get_suffix(struct string *s, gs_uint32_t n);


/* Basic string operation */

gs_retval_t str_assign_with_copy(struct FTA *, struct string * dest, struct string * src);

gs_retval_t str_assign_with_copy_in_tuple(struct string32 * dest, struct string * src, 
				  gs_sp_t start, gs_sp_t buf);

#define str_destroy(s) {if ((s)->owner!=0) fta_free((s)->owner,(s)->data);}   

gs_retval_t str_replace(struct FTA *,  struct string * dest, struct string * src );

#define str_length(s) (s)->length

/* Searching within a string */

gs_retval_t str_exists_substr( struct string * str1, struct string * str2);

/* String comparison */

gs_retval_t str_compare( struct string * str1, struct string * str2);


/*	Construct a string constant */

gs_retval_t str_constructor(struct string *s, gs_sp_t l);


/* External Function definitions */

#define LLMIN(x,y) ((x)<(y)?(x):(y))
#define LLMAX(x,y) ((x)<(y)?(y):(x))
#define UMIN(x,y) ((x)<(y)?(x):(y))
#define UMAX(x,y) ((x)<(y)?(y):(x))
// simple if statement
#define IF(c,t,f) (((c)!=0)?(t):(f))
// type conversion
#define INT(c) ((int)(c))
#define UINT(c) ((unsigned int)(c))
#define ULLONG(c) ((unsigned long long)(c))
#define TIMESTAMPTOMSEC(c) ((unsigned int) (((c)&0xffffffff)/4294967))

//	Cast away temporality
#define non_temporal(x)(x)

gs_param_handle_t register_handle_for_getlpmid_slot_1(struct FTA *f, struct string * s1);
gs_int32_t getlpmid(gs_uint32_t ip, gs_param_handle_t handle );
void deregister_handle_for_getlpmid_slot_1(gs_param_handle_t handle);
gs_param_handle_t register_handle_for_getfirstlpmid_slot_2(struct FTA *, struct string * s1);
void deregister_handle_for_getfirstlpmid_slot_2(gs_param_handle_t handle);


gs_uint32_t str_match_offset( gs_uint32_t offset, struct string * s1, struct string * s2);
gs_uint32_t byte_match_offset( gs_uint32_t offset, gs_uint32_t val, struct string * s2);
gs_uint32_t byte_match_reverse_offset( gs_uint32_t offset, gs_uint32_t val, struct string * s2);
gs_uint32_t net_word_match_offset( gs_uint32_t offset, gs_uint32_t val, struct string * s2);
gs_uint32_t little_endian_word_match_offset( gs_uint32_t offset, 
				      gs_uint32_t val, struct string * s2);
gs_param_handle_t register_handle_for_str_file_regex_match_slot_1(struct FTA * f,
                                        struct string* filename);
gs_uint32_t str_file_regex_match(struct string* str, gs_param_handle_t handle, gs_uint32_t timeout, gs_uint32_t time);
gs_retval_t deregister_handle_for_str_file_regex_match_slot_1(gs_param_handle_t handle);
 
gs_param_handle_t register_handle_for_str_regex_match_slot_1(struct FTA * f, 
					   struct string* pattern);
gs_uint32_t str_regex_match(struct string* str, gs_param_handle_t pattern_handle);
gs_retval_t deregister_handle_for_str_regex_match_slot_1(gs_param_handle_t handle);

gs_param_handle_t register_handle_for_str_partial_regex_match_slot_1(struct FTA * f, 
						   struct string* pattern);
gs_uint32_t str_partial_regex_match(struct string* str, 
			     gs_param_handle_t pattern_handle,
			     gs_uint32_t maxlen);
gs_retval_t deregister_handle_for_str_partial_regex_match_slot_1(
							 gs_param_handle_t 
							 handle);

inline static gs_retval_t str_truncate(struct string * result, struct string *str, gs_uint32_t length) {
	result->data=str->data;
	result->length=(str->length<length)?str->length:length;
	result->owner=0;
	return 0;
}

inline static gs_uint32_t STRID(struct string *str) {
   gs_uint32_t res=0;
   gs_uint8_t c;
   if (str->length>0) c=((gs_uint8_t) str->data[0]); else c=0;
   res=(res|(gs_uint32_t)c)<<8;
   if (str->length>1) c=((gs_uint8_t) str->data[1]); else c=0;
   res=(res|(gs_uint32_t)c)<<8;
   if (str->length>2) c=((gs_uint8_t) str->data[2]); else c=0;
   res=(res|(gs_uint32_t)c)<<8;
   if (str->length>3) c=((gs_uint8_t) str->data[3]); else c=0;
   return (res|(gs_uint32_t)c);
}

//	constant string conversions
gs_param_handle_t register_handle_for_strtoi_c_slot_0(struct FTA * f, struct string* istr) ;
gs_retval_t deregister_handle_for_strtoi_c_slot_0(gs_param_handle_t h) ;
#define strtoi_c(h) ((unsigned int)(h)) 

gs_param_handle_t register_handle_for_strtoip_c_slot_0(struct FTA * f, struct string* istr) ;
gs_retval_t deregister_handle_for_strtoip_c_slot_0(gs_param_handle_t h) ;
#define strtoip_c(h) ((unsigned int)(h)) 


/// Mayor hack until ted has triggered aggregates available XXX OS

gs_param_handle_t register_handle_for_rtp_loss_slot_0(struct FTA * f, gs_uint32_t c);
gs_retval_t deregister_handle_for_rtp_loss_slot_0(gs_param_handle_t handle);


////////////////////////////////////////////////
///		IPV6

#ifndef IPV6_STR
#define IPV6_STR
struct ipv6_str{
	gs_uint32_t v[4];
};
#endif

gs_int32_t ipv6_compare( struct ipv6_str  i1, struct ipv6_str  i2);
gs_int32_t Ipv6_Constructor(struct ipv6_str *s, char *l);
struct ipv6_str And_Ipv6(const struct ipv6_str i1, const struct ipv6_str i2);
struct ipv6_str Or_Ipv6(const struct ipv6_str i1, const struct ipv6_str i2);
struct ipv6_str hton_ipv6(struct ipv6_str s);
struct ipv6_str ntoh_ipv6(struct ipv6_str s);

#endif
