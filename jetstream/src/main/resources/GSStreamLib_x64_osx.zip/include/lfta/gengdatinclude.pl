#!/usr/bin/perl
open(I,"cat ../packet.h | grep '#define GDATELEMENTS' | cut -f 3 -d ' ' |");
$num=<I>;
close(I);
chomp $num;
printf("#ifndef GDAT_MACRO_H\n#define GDAT_MACRO_H\n");
for($x=1;$x<=$num;$x++) {
	printf "#define get_gdat_uint_pos$x(X,Y) get_gdat_uint((X),(Y),$x)\n";
        printf "#define get_gdat_ullong_pos$x(X,Y) get_gdat_ullong((X),(Y),$x)\n";
        printf "#define get_gdat_ip_pos$x(X,Y) get_gdat_ip((X),(Y),$x)\n";
        printf "#define get_gdat_ipv6_pos$x(X,Y) get_gdat_ipv6((X),(Y),$x)\n";
        printf "#define get_gdat_string_pos$x(X,Y) get_gdat_string((X),(Y),$x)\n";
        printf "#define get_gdat_bool_pos$x(X,Y) get_gdat_bool((X),(Y),$x)\n";
        printf "#define get_gdat_int_pos$x(X,Y) get_gdat_int((X),(Y),$x)\n";
        printf "#define get_gdat_llong_pos$x(X,Y) get_gdat_llong((X),(Y),$x)\n";
        printf "#define get_gdat_float_pos$x(X,Y) get_gdat_float((X),(Y),$x)\n";
}
print("#endif\n");
