#!/usr/bin/perl
open(I,"cat ../packet.h | grep '#define CSVELEMENTS' | cut -f 3 -d ' ' |");
$num=<I>;
close(I);
chomp $num;
printf("#ifndef CSV_MACRO_H\n#define CSV_MACRO_H\n");
for($x=1;$x<=$num;$x++) {
	printf "#define get_csv_uint_pos$x(X,Y) get_csv_uint((X),(Y),$x)\n";
        printf "#define get_csv_ullong_pos$x(X,Y) get_csv_ullong((X),(Y),$x)\n";
        printf "#define get_csv_ip_pos$x(X,Y) get_csv_ip((X),(Y),$x)\n";
        printf "#define get_csv_ipv6_pos$x(X,Y) get_csv_ipv6((X),(Y),$x)\n";
        printf "#define get_csv_string_pos$x(X,Y) get_csv_string((X),(Y),$x)\n";
        printf "#define get_csv_bool_pos$x(X,Y) get_csv_bool((X),(Y),$x)\n";
        printf "#define get_csv_int_pos$x(X,Y) get_csv_int((X),(Y),$x)\n";
        printf "#define get_csv_llong_pos$x(X,Y) get_csv_llong((X),(Y),$x)\n";
        printf "#define get_csv_float_pos$x(X,Y) get_csv_float((X),(Y),$x)\n";
}
print("#endif\n");
