#ifndef BYTESWAP_H
#define BYTESWAP_H

#ifdef __cplusplus
extern "C" {
#endif

#include "gsconfig.h"
#include "gstypes.h"


gs_uint16_t gscpbswap16(gs_uint16_t);
gs_uint32_t gscpbswap32(gs_uint32_t);
gs_uint64_t gscpbswap64(gs_uint64_t);

#ifdef __cplusplus
}
#endif

#undef ntohl
#undef ntohs
#undef htons
#undef htonl
#undef htonll
#undef ntohll


#define	ntohs(x)	gscpbswap16((gs_uint16_t)(x))
#define	ntohl(x)	gscpbswap32((gs_uint32_t)(x))
#define ntohll(x)       gscpbswap64((gs_uint64_t)(x))
#define	htons(x)	gscpbswap16((gs_uint16_t)(x))
#define	htonl(x)	gscpbswap32((gs_uint32_t)(x))
#define htonll(x)       gscpbswap64((gs_uint64_t)(x))

/* do nothing fo floating point numbers */
#define htonf(x)        (x)
#define ntohf(x)        (x)


#endif
