#ifndef PACKET_H
#define PACKET_H

#include "gsconfig.h"
#include "gstypes.h"

#ifndef IPV6_STR
#define IPV6_STR
struct ipv6_str{
        gs_uint32_t v[4];
};
#endif

#define PTYPE_CSV 1
#define PTYPE_GDAT 2

#define CSVELEMENTS 1000
#define GDATELEMENTS 1000

struct csv {
  gs_uint32_t numberfields;
  gs_uint8_t * fields[CSVELEMENTS];
};

struct gdat {
  gs_schemahandle_t schema;
  gs_uint32_t numfields;
  gs_uint32_t datasz;
  gs_uint8_t data[MAXTUPLESZ];
};

struct packet {
  gs_uint32_t systemTime;
  gs_uint32_t ptype; /* type of record e.g. PTYPE_CSV */
  union {
	struct csv csv; /* content of CSV record being processed */
	struct gdat gdat;
	} record;

};


#endif
